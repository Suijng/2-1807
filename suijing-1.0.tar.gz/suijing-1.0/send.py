def sends():
	print('接收短信')







