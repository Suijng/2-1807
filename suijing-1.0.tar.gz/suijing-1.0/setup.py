
from distutils.core import setup

setup(name="suijing", version="1.0", description="suijing's module", author="xiaoyuan", py_modules=['send','read'])
