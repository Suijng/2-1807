def reads():
	print('发短信')





